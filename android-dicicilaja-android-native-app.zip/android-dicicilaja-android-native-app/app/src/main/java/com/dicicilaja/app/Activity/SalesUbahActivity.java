package com.dicicilaja.app.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.dicicilaja.app.R;

public class SalesUbahActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales_ubah);
    }
}
