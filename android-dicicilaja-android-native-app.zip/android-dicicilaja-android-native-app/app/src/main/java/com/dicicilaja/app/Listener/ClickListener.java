package com.dicicilaja.app.Listener;

import android.view.View;

/**
 * Created by ziterz on 05/01/2018.
 */

public interface ClickListener {
    void onClick(View view, int position);

    void onLongClick(View view, int position);
}
